import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { Link } from "react-router-dom";
import {
  Row,
  Col,
  Form,
  Button,
  Alert,
  Spinner,
  InputGroup,
  Modal,
  Toast,
  ToastContainer
} from "react-bootstrap";
import axios from "axios";
import config from "../../../config";
import { all_routes } from "../../../Router/all_routes";
import { FaSyncAlt, FaSearch } from "react-icons/fa";
import Notification from "../../Notification/Notification";
import DatePicker from "react-datepicker";
import { createPortal } from "react-dom";
import "react-datepicker/dist/react-datepicker.css";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import "./Delivery.css";
import moment from "moment";
import { getCompanyBranchDetails } from "./companyBranches";
import { findCustomerRecord, mergeFallbackCustomers } from "./customerFallbacks";
import {
  buildChallanItemPricing,
  formatAmount,
  getTotalJobValue,
} from "./hsnRateLookup";

const DeliveryTimestampCell = (props) => {
  const { data, context } = props;
  const rowId = data?.id;
  if (!rowId) return null;

  const isLocked =
    !!data?.deliveryTimestampUtc ||
    !!data?.DeliveryTimestampUtc ||
    !!data?.deliveryTimestamp ||
    !!data?.DeliveryTimestamp;

  const initialIso =
    context?.rowTimestamps?.[rowId] ||
    data?.deliveryTimestampUtc ||
    data?.DeliveryTimestampUtc ||
    data?.deliveryTimestamp ||
    data?.DeliveryTimestamp ||
    "";

  const [draft, setDraft] = useState(initialIso ? new Date(initialIso) : null);

  useEffect(() => {
    const iso =
      context?.rowTimestamps?.[rowId] ||
      data?.deliveryTimestampUtc ||
      data?.DeliveryTimestampUtc ||
      data?.deliveryTimestamp ||
      data?.DeliveryTimestamp ||
      "";

    setDraft(iso ? new Date(iso) : null);
  }, [
    context,
    rowId,
    data?.deliveryTimestampUtc,
    data?.DeliveryTimestampUtc,
    data?.deliveryTimestamp,
    data?.DeliveryTimestamp,
  ]);

  return (
    <div
      onMouseDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
      style={{ display: "flex", gap: 6, alignItems: "center" }}
    >
      <DatePicker
        selected={draft}
        onChange={(date) => {
          if (isLocked) return;
          setDraft(date);
          context.setRowTimestamps((prev) => ({
            ...prev,
            [rowId]: date ? date.toISOString() : "",
          }));
        }}
        showTimeSelect
        timeIntervals={15}
        timeCaption="Time"
        dateFormat="yyyy-MM-dd HH:mm"
        placeholderText={isLocked ? "Locked" : "Pick date then time"}
        className="form-control form-control-sm"
        disabled={isLocked}
        readOnly={isLocked}
        isClearable={false}
        popperPlacement="bottom-start"
        popperContainer={({ children }) => createPortal(children, document.body)}
      />
    </div>
  );
};

const getAnyField = (row, keys) => {
  for (const key of keys) {
    const value = row?.[key];
    if (value !== undefined && value !== null && String(value).trim() !== "") {
      return value;
    }
  }
  return "";
};

const isTruthyFlag = (value) => {
  const normalized = String(value ?? "").trim().toLowerCase();
  return normalized === "1" || normalized === "true" || normalized === "yes";
};

const getDeliveryChallanMeta = (row) => {
  const id = getAnyField(row, [
    "deliveryChallanId",
    "DeliveryChallanId",
    "challanId",
    "ChallanId",
  ]);
  const no = getAnyField(row, [
    "deliveryChallanNo",
    "DeliveryChallanNo",
    "challanNo",
    "ChallanNo",
  ]);
  const created = getAnyField(row, [
    "isDeliveryChallanCreated",
    "IsDeliveryChallanCreated",
  ]);

  return {
    id,
    no,
    isCreated: Boolean(id || no || isTruthyFlag(created)),
  };
};

const Delivery = () => {
  const [locationData, setLocationData] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [deliveryBy, setDeliveryBy] = useState("");
  const [deliveryDate, setDeliveryDate] = useState("");
  const [deliveryOutDate, setDeliveryOutDate] = useState("");
  const [handTempoDelivery, setHandTempoDelivery] = useState("");
  const [deliverPersonName, setDeliverPersonName] = useState([]);
  const [deliverPersonNameSelect, setDeliverPersonNameSelect] = useState("");
  const [customers, setCustomers] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState("");
  const [rowTimestamps, setRowTimestamps] = useState({});
  const [locationId, setLocationId] = useState("");
  const [notificationMessage, setNotificationMessage] = useState("");
  const [showNotification, setShowNotification] = useState(false);
  const [showChallanModal, setShowChallanModal] = useState(false);
  const [challanForm, setChallanForm] = useState({
    customerAddress: "",
    customerGstNo: "",
    storeAddress: "",
    cpName: "",
    jobValue: "",
    items: [],
  });

  // const [bulkTimestamp, setBulkTimestamp] = useState(null);
  // const [bulkSaving, setBulkSaving] = useState(false);

  const [showTopToast, setShowTopToast] = useState(false);
  const [topToastMessage, setTopToastMessage] = useState("");
  const [topToastVariant, setTopToastVariant] = useState("danger");

  const gridRef = useRef();
  const deliveryRequestRef = useRef(null);
  const loadedDeliveryKeyRef = useRef("");

  const triggerTopToast = useCallback((message, variant = "danger") => {
    setTopToastMessage(message);
    setTopToastVariant(variant);
    setShowTopToast(true);
  }, []);

  useEffect(() => {
    const users = JSON.parse(localStorage.getItem("users"));
    if (users?.message) {
      setUsername(users.message.username);
      setLocationId(users.message.location_id);
    }
  }, []);

  const fetchCustomerDetails = useCallback(async () => {
    if (!locationId) return;

    try {
      const response = await axios.post(
        config.JobSummary.URL.Getallcustomer,
        { locationid: locationId },
        {
          timeout: 10000,
          headers: { "Content-Type": "application/json" },
        }
      );

      setCustomers(mergeFallbackCustomers(response.data));
    } catch (error) {
      console.error(
        "Error fetching customer data:",
        error.response ? error.response.data : error.message
      );
    }
  }, [locationId]);

  const fetchDeliveryByLocation = useCallback(
    async ({ forceRefresh = false } = {}) => {
      if (!locationId || !username) return;

      const requestKey = `${locationId}|${username}`;

      if (!forceRefresh && loadedDeliveryKeyRef.current === requestKey) {
        return;
      }

      if (!forceRefresh && deliveryRequestRef.current) {
        return deliveryRequestRef.current;
      }

      const request = (async () => {
        try {
          setLoading(true);
          setError(null);

          const payload = { locationId, username };
          const response = await axios.post(
            config.Delivery.URL.GetAllDeliveryAccToLocation,
            payload,
            {
              timeout: 15000,
              headers: { "Content-Type": "application/json" },
            }
          );

          const rows = Array.isArray(response.data)
            ? response.data
            : Array.isArray(response.data?.data)
            ? response.data.data
            : [];

          const normalizedRows = rows.map((row, index) => ({
            ...row,
            __rowKey: String(
              row.id ||
                row.deliveryid ||
                `${row.jobNo || "delivery"}-${index}`
            ),
          }));

          setLocationData(normalizedRows);
          setSelectedRows([]);
          loadedDeliveryKeyRef.current = requestKey;

          const timestampMap = {};
          normalizedRows.forEach((row) => {
            const iso =
              row.deliveryTimestampUtc ||
              row.DeliveryTimestampUtc ||
              row.deliveryTimestamp ||
              row.DeliveryTimestamp ||
              "";

            if (iso && row.id) {
              timestampMap[row.id] = iso;
            }
          });

          setRowTimestamps(timestampMap);
        } catch (err) {
          console.error("Error fetching delivery data:", err);
          setError(
            err?.response?.data?.message ||
              err?.response?.data ||
              "Error fetching delivery data"
          );
        } finally {
          setLoading(false);
          deliveryRequestRef.current = null;
        }
      })();

      deliveryRequestRef.current = request;
      return request;
    },
    [locationId, username]
  );

  useEffect(() => {
    if (!locationId || !username) return;

    fetchDeliveryByLocation();

    let idleId;
    let timeoutId;

    if (typeof window !== "undefined" && window.requestIdleCallback) {
      idleId = window.requestIdleCallback(fetchCustomerDetails, {
        timeout: 1200,
      });
    } else {
      timeoutId = window.setTimeout(fetchCustomerDetails, 150);
    }

    return () => {
      if (idleId && window.cancelIdleCallback) {
        window.cancelIdleCallback(idleId);
      }
      if (timeoutId) {
        window.clearTimeout(timeoutId);
      }
    };
  }, [
    locationId,
    username,
    fetchDeliveryByLocation,
    fetchCustomerDetails,
  ]);

  useEffect(() => {
    if (!locationId) return;

    axios
      .post(config.User.URL.GetAllUserAccToLocation, { locationId })
      .then((res) => setDeliverPersonName(res.data || []))
      .catch(console.error);
  }, [locationId]);

  const filteredUserNames = useMemo(
    () => [...new Set(deliverPersonName.filter(Boolean))],
    [deliverPersonName]
  );

  const handleDeliverNameChange = (e) => {
    setDeliverPersonNameSelect(e.target.value);
  };

  const getSelectedExactRows = useCallback(() => {
    const nodes = gridRef.current?.api?.getSelectedNodes?.() || [];
    return nodes.map((n) => n.data).filter((r) => r?.id);
  }, []);

  const clearSelectedRows = useCallback(() => {
    gridRef.current?.api?.deselectAll();
    setSelectedRows([]);
  }, []);

  const formatDisplayDate = (dateVal) => {
    if (!dateVal) return "";
    const m = moment(dateVal);
    return m.isValid() ? m.format("DD-MM-YYYY") : dateVal;
  };

  const buildItemDetails = (row) => {
    const parts = [
      row.media,
      row.lamination,
      row.mounting,
      row.implementation,
      row.nameSubCode || row.visualCode,
    ].filter(Boolean);

    return parts.join(" - ");
  };

  const toTrimmedText = (value) => String(value ?? "").trim();

  const firstNonEmpty = (...values) => {
    for (const value of values) {
      const text = toTrimmedText(value);
      if (text) return text;
    }
    return "";
  };

  const buildCustomerBillingAddress = (customer, row) => {
    const customerAddress = [
      customer?.billinG_ADD1,
      customer?.billinG_ADD2,
      `${customer?.billinG_CITY || ""}${
        customer?.billinG_CITY && customer?.billinG_PINCODE ? " - " : ""
      }${customer?.billinG_PINCODE || ""}`,
    ]
      .filter((x) => x && String(x).trim() !== "")
      .join(", ");

    return firstNonEmpty(
      customerAddress,
      row?.customerAddress,
      row?.CustomerAddress,
      row?.address,
      row?.Address,
      row?.billingAddress,
      row?.BillingAddress,
      row?.storeAddress,
      row?.StoreAddress,
      row?.salonAddress,
      row?.SalonAddress,
      row?.dispatchAddress,
      row?.DispatchAddress
    );
  };

  const getStoreAddressFallback = (row) =>
    firstNonEmpty(
      row?.storeAddress,
      row?.StoreAddress,
      row?.salonAddress,
      row?.SalonAddress,
      row?.dispatchAddress,
      row?.DispatchAddress,
      row?.customerAddress,
      row?.CustomerAddress
    );

  const getDispatchAddressFallback = (row) =>
    firstNonEmpty(row?.dispatchAddress, row?.DispatchAddress, row?.storeAddress, row?.StoreAddress, row?.salonAddress, row?.SalonAddress);

  const resolveDeliveryChallanForm = useCallback(
    (form = challanForm, rows = []) => {
      const firstRow = rows[0] || {};
      const customer = findCustomerRecord(customers, firstRow);
      return {
        ...form,
        customerAddress: firstNonEmpty(form.customerAddress, buildCustomerBillingAddress(customer, firstRow)),
        customerGstNo: firstNonEmpty(form.customerGstNo, customer?.gsT_NO, firstRow?.customerGstNo, firstRow?.CustomerGstNo),
        storeAddress: firstNonEmpty(form.storeAddress, getStoreAddressFallback(firstRow)),
        dispatchAddress: firstNonEmpty(form.dispatchAddress, getDispatchAddressFallback(firstRow)),
      };
    },
    [challanForm, customers]
  );

  const getNormalizedProductionLocation = useCallback(
    (row) => String(row?.region || row?.productionLocation || "").trim().toLowerCase(),
    []
  );

  const getNormalizedCustomerKey = useCallback(
    (row) => {
      const customer = findCustomerRecord(customers, row);
      return String(
        customer?.customeR_ID ||
          row?.customerId ||
          row?.customerid ||
          row?.CUSTOMER_ID ||
          row?.customeR_ID ||
          row?.customer_id ||
          row?.CustomerId ||
          customer?.customeR_NAME ||
          row?.customerName ||
          row?.customername ||
          row?.clientName ||
          row?.client ||
          row?.subClient ||
          ""
      )
        .trim()
        .toLowerCase();
    },
    [customers]
  );

  const getUniqueJobNos = useCallback(
    (rows) =>
      [...new Set(rows.map((row) => String(row?.jobNo || "").trim()).filter(Boolean))].join(", "),
    []
  );

  const buildDeliveryChallanForm = useCallback(
    (selectedData) => {
      const firstRow = selectedData[0];
      const customer = findCustomerRecord(customers, firstRow);
      const items = selectedData.map((row, index) => {
        const pricing = buildChallanItemPricing(row);

        return {
          rowId: row.deliveryid || row.id || "",
          csId: row.id || "",
          jobNo: row.jobNo || "",
          sno: index + 1,
          details: buildItemDetails(row),
          hsnCode: pricing.hsnCode,
          unitPrice: pricing.unitPrice,
          totalSqFt: pricing.totalSqFt,
          width: row.width || "",
          height: row.height || row.length || "",
          size: `${row.width || ""} X ${row.height || row.length || ""}`,
          quantity: String(row.qty || 0),
          lineJobValue: pricing.lineJobValue,
        };
      });

      return {
        customerAddress: buildCustomerBillingAddress(customer, firstRow),
        customerGstNo: firstNonEmpty(customer?.gsT_NO, firstRow?.customerGstNo, firstRow?.CustomerGstNo),
        storeAddress: getStoreAddressFallback(firstRow),
        dispatchAddress: getDispatchAddressFallback(firstRow),
        cpName:
          firstRow?.contactPersonName ||
          firstRow?.contactPerson ||
          firstRow?.contactperson ||
          customer?.contacT_PERSON ||
          "",
        jobValue: formatAmount(getTotalJobValue(items)),
        items,
      };
    },
    [customers]
  );

  const handleOpenDeliveryChallanModal = useCallback(() => {
    const selectedData = getSelectedExactRows();
    const effectiveSelectedData = selectedData.length ? selectedData : selectedRows;

    if (!effectiveSelectedData.length) {
      triggerTopToast("Please select at least one row", "danger");
      return;
    }

    const uniqueLocations = [
      ...new Set(
        effectiveSelectedData
          .map((row) => getNormalizedProductionLocation(row))
          .filter(Boolean)
      ),
    ];

    if (uniqueLocations.length > 1) {
      triggerTopToast(
        "Please select line items from the same production location only",
        "warning"
      );
      return;
    }

    const uniqueCustomers = [
      ...new Set(
        effectiveSelectedData
          .map((row) => getNormalizedCustomerKey(row))
          .filter(Boolean)
      ),
    ];

    if (uniqueCustomers.length > 1) {
      triggerTopToast(
        "Please select line items for the same customer only",
        "warning"
      );
      return;
    }

    setChallanForm(buildDeliveryChallanForm(effectiveSelectedData));
    setShowChallanModal(true);
  }, [
    getSelectedExactRows,
    selectedRows,
    triggerTopToast,
    buildDeliveryChallanForm,
    getNormalizedProductionLocation,
    getNormalizedCustomerKey,
  ]);

  const validateDeliveryChallanForm = useCallback((form = challanForm) => {
    if (!form.customerAddress?.trim()) {
      triggerTopToast("Please enter address", "danger");
      return false;
    }
    if (!form.storeAddress?.trim()) {
      triggerTopToast("Please enter store address", "danger");
      return false;
    }
    if (!form.customerGstNo?.trim()) {
      triggerTopToast("Please enter GST No", "danger");
      return false;
    }
    if (!String(form.jobValue || "").trim() || Number(form.jobValue || 0) <= 0) {
      triggerTopToast("Please enter Job Value", "danger");
      return false;
    }
    return true;
  }, [challanForm, triggerTopToast]);

  const handleAddDeliveryJob = async (e) => {
    e.preventDefault();

    const selectedJobs = getSelectedExactRows().map((row) => ({
      id: row.id,
      productionid: row.productionid,
      jobNo: row.jobNo,
      clientName: row.client,
      subClient: row.subClient,
      date: row.date,
      userName: row.userName,
      location: row.region,
      visualCode: row.visualCode,
      nameSubCode: row.nameSubCode,
      city: row.city,
      qty: row.qty,
      media: row.media,
      lamination: row.lamination,
      mounting: row.mounting,
      salonAddress: row.salonAddress,
      dispatchAddress: row.dispatchAddress,
      deadline: row.deadline,
      remarks: row.remarks,
      actCompleteTime: row.actCompleteTime,
      onTimeDelayed: row.onTimeDelayed,
      entereddt: row.entereddt,
      lstupdatedt: new Date().toISOString(),
      lstupateby: username,
      user: username,
      width: row.width,
      height: row.height,
      totalSqFt: row.totalSqFt,
      deliveryBy,
      deliveryDate,
      deliveryOutDate,
      deliveryTo: deliverPersonNameSelect,
      handTempoDelivery,
    }));

    if (!selectedJobs.length) {
      triggerTopToast("Please select at least one job", "danger");
      return;
    }

    try {
      await axios.post(config.Delivery.URL.AddDelivery, selectedJobs);
      window.location.reload();
    } catch (err) {
      setError("Failed to submit jobs");
    }
  };

const handleCreateDeliveryChallan = async () => {
  try {
    const selectedData = getSelectedExactRows();
    const effectiveSelectedData = selectedData.length ? selectedData : selectedRows;

    if (!effectiveSelectedData.length) {
      triggerTopToast("Please select at least one row", "danger");
      return;
    }

    const resolvedChallanForm = resolveDeliveryChallanForm(challanForm, effectiveSelectedData);
    setChallanForm(resolvedChallanForm);
    if (!validateDeliveryChallanForm(resolvedChallanForm)) return;

    // save timestamp + mark done before challan creation
    await saveTimestampBeforeDeliveryChallan(effectiveSelectedData);

    const firstRow = effectiveSelectedData[0];

    const selectedCustomerId =
      firstRow.customerId ||
      firstRow.CUSTOMER_ID ||
      firstRow.customeR_ID ||
      firstRow.customer_id ||
      firstRow.CustomerId ||
      "";

    const customer = findCustomerRecord(customers, firstRow);
    const branchDetails = getCompanyBranchDetails(
      firstRow.region || firstRow.productionLocation
    );

    const challanPayload = {
      challanDate: moment().format("DD-MM-YYYY"),

      companyName: branchDetails.companyName,
      companyAddress: branchDetails.companyAddress,
      companyPhone: branchDetails.companyPhone,
      companyGst: branchDetails.companyGst,
      companyLogo: branchDetails.companyLogo,

      customerId: String(selectedCustomerId || ""),
      customerName: customer?.customeR_NAME || firstRow.client || "",
      customerAddress: resolvedChallanForm.customerAddress,
      customerGstNo: resolvedChallanForm.customerGstNo,

      projectName: firstRow.visualCode || "",
      cpName: resolvedChallanForm.cpName,
      contactPersonPhone: firstRow.contactPersonPhone || "",

      jobNo: getUniqueJobNos(effectiveSelectedData),
      jobValue: resolvedChallanForm.jobValue,
      poNo: firstRow.poNo || "",
      poDate: formatDisplayDate(firstRow.poDate),

      storeName: firstRow.storeName || firstRow.city || "",
      storeAddress: resolvedChallanForm.storeAddress,
      productionLocation: firstRow.region || firstRow.productionLocation || "",
      dispatchAddress: resolvedChallanForm.dispatchAddress || firstRow.dispatchAddress || "",
      remarks: firstRow.remarks || "",

      preparedBy: username || "",
      receivedBy: "",
      receivedDate: "",

      locationId: String(locationId || ""),
      createdBy: username || "",

      items: resolvedChallanForm.items.map((item) => ({
        ...item,
        csId: item.csId || item.rowId,
        hsnCode: item.hsnCode || "",
        unitPrice: Number(item.unitPrice || 0),
        lineJobValue: Number(item.lineJobValue || 0),
      })),
    };

    const response = await axios.post(
      config.Delivery.URL.CreateDeliveryChallan,
      challanPayload,
      { headers: { "Content-Type": "application/json" } }
    );

    const savedChallan = response.data;
    const savedItems = savedChallan.items || savedChallan.Items || [];
    const previewItems = (Array.isArray(savedItems) && savedItems.length ? savedItems : challanPayload.items || []).map(
      (item, index) => ({
        ...(challanPayload.items?.[index] || {}),
        ...item,
        hsnCode: item.hsnCode || item.HsnCode || challanPayload.items?.[index]?.hsnCode || "",
        unitPrice: item.unitPrice ?? item.UnitPrice ?? challanPayload.items?.[index]?.unitPrice ?? 0,
        totalSqFt: item.totalSqFt ?? item.TotalSqFt ?? challanPayload.items?.[index]?.totalSqFt ?? 0,
        lineJobValue:
          item.lineJobValue ??
          item.LineJobValue ??
          item.jobValue ??
          item.JobValue ??
          challanPayload.items?.[index]?.lineJobValue ??
          0,
      })
    );

    localStorage.setItem(
      "challanPreviewData",
      JSON.stringify({
        companyName:
          savedChallan.companyName || savedChallan.CompanyName || challanPayload.companyName,
        companyAddress:
          savedChallan.companyAddress ||
          savedChallan.CompanyAddress ||
          challanPayload.companyAddress,
        companyPhone:
          savedChallan.companyPhone || savedChallan.CompanyPhone || challanPayload.companyPhone,
        companyGst:
          savedChallan.companyGst || savedChallan.CompanyGst || challanPayload.companyGst,
        companyLogo:
          savedChallan.companyLogo || savedChallan.CompanyLogo || challanPayload.companyLogo,
        name:
          savedChallan.customerName || savedChallan.CustomerName || challanPayload.customerName,
        address:
          savedChallan.customerAddress ||
          savedChallan.CustomerAddress ||
          challanPayload.customerAddress,
        gstNo:
          savedChallan.customerGstNo ||
          savedChallan.CustomerGstNo ||
          challanPayload.customerGstNo,
        projectName:
          savedChallan.projectName || savedChallan.ProjectName || challanPayload.projectName,
        cpName: savedChallan.cpName || savedChallan.CpName || challanPayload.cpName,
        contactPersonPhone:
          savedChallan.contactPersonPhone ||
          savedChallan.ContactPersonPhone ||
          challanPayload.contactPersonPhone,
        challanNo: savedChallan.challanNo || savedChallan.ChallanNo,
        challanDt: savedChallan.challanDate || savedChallan.ChallanDate,
        jobNo: savedChallan.jobNo || savedChallan.JobNo || challanPayload.jobNo,
        jobValue: savedChallan.jobValue || savedChallan.JobValue || challanPayload.jobValue,
        poNo: savedChallan.poNo || savedChallan.PoNo || challanPayload.poNo,
        poDate: savedChallan.poDate || savedChallan.PoDate || challanPayload.poDate,
        storeName: savedChallan.storeName || savedChallan.StoreName || challanPayload.storeName,
        storeAddress:
          savedChallan.storeAddress ||
          savedChallan.StoreAddress ||
          challanPayload.storeAddress,
        productionLocation:
          savedChallan.productionLocation ||
          savedChallan.ProductionLocation ||
          challanPayload.productionLocation,
        dispatchAddress:
          savedChallan.dispatchAddress ||
          savedChallan.DispatchAddress ||
          challanPayload.dispatchAddress,
        remarks: savedChallan.remarks || savedChallan.Remarks || challanPayload.remarks,
        preparedBy:
          savedChallan.preparedBy || savedChallan.PreparedBy || challanPayload.preparedBy,
        receivedBy: savedChallan.receivedBy || savedChallan.ReceivedBy,
        receivedDate: savedChallan.receivedDate || savedChallan.ReceivedDate,
        items: previewItems,
      })
    );

    setShowChallanModal(false);
    clearSelectedRows();
    window.open(`/deliverychallan/`, "_blank");
    await fetchDeliveryByLocation({ forceRefresh: true });
    clearSelectedRows();

    triggerTopToast(
      `Delivery challan created: ${savedChallan.challanNo || savedChallan.ChallanNo}`,
      "success"
    );
  } catch (error) {
    console.error("Error creating delivery challan:", error);
    triggerTopToast(
      error?.response?.data || error?.message || "Failed to create delivery challan",
      "danger"
    );
  }
};

  const filteredData = useMemo(() => {
    return locationData.filter((row) =>
      row.jobNo?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [locationData, searchTerm]);

  const handleSelectionChanged = useCallback(() => {
    const selected = getSelectedExactRows();
    setSelectedRows(selected);
  }, [getSelectedExactRows]);


  const saveTimestampBeforeDeliveryChallan = useCallback(
  async (rows) => {
    const unlockedRows = rows.filter((row) => {
      const locked =
        !!row?.deliveryTimestampUtc ||
        !!row?.DeliveryTimestampUtc ||
        !!row?.deliveryTimestamp ||
        !!row?.DeliveryTimestamp;
      return !locked;
    });

    if (!unlockedRows.length) return;

    const nowIsoUtc = new Date().toISOString();

    await Promise.all(
      unlockedRows.map((row) =>
        axios.post(config.Delivery.URL.UpdateTimestamp, {
          id: row.id,
          jobNo: row.jobNo,
          timestampUtc: nowIsoUtc,
          updatedBy: username,
        })
      )
    );

    const selectedIds = new Set(unlockedRows.map((x) => x.id));

    setRowTimestamps((prev) => {
      const updated = { ...prev };
      unlockedRows.forEach((row) => {
        updated[row.id] = nowIsoUtc;
      });
      return updated;
    });

    setLocationData((prev) =>
      prev.map((r) =>
        selectedIds.has(r.id)
          ? {
              ...r,
              deliveryTimestampUtc: nowIsoUtc,
              deliveryTimestamp: nowIsoUtc,
              IsDeliveryDone: "1",
            }
          : r
      )
    );
  },
  [username]
);

  // const saveTimestamp = useCallback(
  //   async (rowId, isoUtc, row) => {
  //     try {
  //       setError(null);

  //       const alreadyLocked =
  //         !!row?.deliveryTimestampUtc ||
  //         !!row?.DeliveryTimestampUtc ||
  //         !!row?.deliveryTimestamp ||
  //         !!row?.DeliveryTimestamp;

  //       if (alreadyLocked) {
  //         triggerTopToast(
  //           `Timestamp already saved for Job ${row?.jobNo || rowId}`,
  //           "warning"
  //         );
  //         return;
  //       }

  //       await axios.post(config.Delivery.URL.UpdateTimestamp, {
  //         id: rowId,
  //         timestampUtc: isoUtc || null,
  //         updatedBy: username,
  //       });

  //       setNotificationMessage(`Delivery timestamp saved for Job ${row?.jobNo || rowId}`);
  //       setShowNotification(true);

  //       setLocationData((prev) =>
  //         prev.map((r) =>
  //           r.id === rowId
  //             ? { ...r, deliveryTimestampUtc: isoUtc, deliveryTimestamp: isoUtc }
  //             : r
  //         )
  //       );

  //       setTimeout(() => {
  //         gridRef.current?.api?.refreshCells({ force: true });
  //       }, 0);
  //     } catch (e) {
  //       console.error(e);
  //       setError(e?.response?.data?.toString?.() || "Failed to save timestamp");
  //     }
  //   },
  //   [username, triggerTopToast]
  // );

  // const handleBulkSaveTimestamp = useCallback(async () => {
  //   try {
  //     setError(null);

  //     if (!bulkTimestamp) {
  //       triggerTopToast("Please select bulk delivery timestamp", "danger");
  //       return;
  //     }

  //     const selected = getSelectedExactRows();

  //     if (!selected.length) {
  //       triggerTopToast("Please select at least one row", "danger");
  //       return;
  //     }

  //     const unlockedRows = selected.filter((row) => {
  //       const locked =
  //         !!row?.deliveryTimestampUtc ||
  //         !!row?.DeliveryTimestampUtc ||
  //         !!row?.deliveryTimestamp ||
  //         !!row?.DeliveryTimestamp;
  //       return !locked;
  //     });

  //     if (!unlockedRows.length) {
  //       triggerTopToast("All selected rows already have timestamp locked", "warning");
  //       return;
  //     }

  //     setBulkSaving(true);

  //     const isoUtc = bulkTimestamp.toISOString();
  //     const selectedIds = new Set(unlockedRows.map((x) => x.id));

  //     setRowTimestamps((prev) => {
  //       const updated = { ...prev };
  //       unlockedRows.forEach((row) => {
  //         updated[row.id] = isoUtc;
  //       });
  //       return updated;
  //     });

  //     await Promise.all(
  //       unlockedRows.map((row) =>
  //         axios.post(config.Delivery.URL.UpdateTimestamp, {
  //           id: row.id,
  //           timestampUtc: isoUtc,
  //           updatedBy: username,
  //         })
  //       )
  //     );

  //     setLocationData((prev) =>
  //       prev.map((r) =>
  //         selectedIds.has(r.id)
  //           ? { ...r, deliveryTimestampUtc: isoUtc, deliveryTimestamp: isoUtc }
  //           : r
  //       )
  //     );

  //     setNotificationMessage(
  //       `Delivery timestamp saved for ${unlockedRows.length} selected row(s)`
  //     );
  //     setShowNotification(true);
  //     setBulkTimestamp(null);

  //     setTimeout(() => {
  //       gridRef.current?.api?.refreshCells({ force: true });
  //     }, 0);
  //   } catch (e) {
  //     console.error(e);
  //     setError(e?.response?.data?.toString?.() || "Failed to bulk save timestamp");
  //   } finally {
  //     setBulkSaving(false);
  //   }
  // }, [bulkTimestamp, username, getSelectedExactRows, triggerTopToast]);

  const handleSelectFilteredRows = useCallback(() => {
    if (!gridRef.current?.api) return;

    gridRef.current.api.forEachNodeAfterFilter((node) => {
      node.setSelected(true);
    });
  }, []);

  const handleClearSelection = useCallback(() => {
    clearSelectedRows();
  }, [clearSelectedRows]);

  const handleOpenInvoicePreview = useCallback(() => {
    const selectedData = getSelectedExactRows();
    const effectiveSelectedData = selectedData.length ? selectedData : selectedRows;

    if (!effectiveSelectedData.length) {
      triggerTopToast("Please select at least one row", "danger");
      return;
    }

    localStorage.setItem(
      "invoicePreviewBuilderData",
      JSON.stringify({
        sourceModule: "delivery",
        selectedRows: effectiveSelectedData,
        customers,
        username,
        locationId,
        createdAt: new Date().toISOString(),
      })
    );

    window.open(all_routes.invoicepreviewbuilder, "_blank");
  }, [customers, getSelectedExactRows, locationId, selectedRows, triggerTopToast, username]);

  const openDeliveryChallanFromRow = useCallback(
    (row) => {
      const meta = getDeliveryChallanMeta(row);
      const customer = findCustomerRecord(customers, row);
      const branchDetails = getCompanyBranchDetails(row?.region || row?.productionLocation);
      const pricing = buildChallanItemPricing(row);

      localStorage.setItem(
        "challanPreviewData",
        JSON.stringify({
          companyName: branchDetails.companyName,
          companyAddress: branchDetails.companyAddress,
          companyPhone: branchDetails.companyPhone,
          companyGst: branchDetails.companyGst,
          companyLogo: branchDetails.companyLogo,
          name: customer?.customeR_NAME || row?.client || "",
          address: row?.customerAddress || row?.CustomerAddress || row?.salonAddress || "",
          gstNo: customer?.gsT_NO || row?.customerGstNo || row?.CustomerGstNo || "",
          challanNo: meta.no,
          challanId: meta.id,
          challanDt: row?.challanDate || row?.ChallanDate || formatDisplayDate(new Date()),
          jobNo: row?.jobNo || "",
          jobValue: formatAmount(pricing.lineJobValue || row?.jobValue || row?.JobValue || 0),
          storeName: row?.storeName || row?.StoreName || row?.salonAddress || "",
          storeAddress: row?.storeAddress || row?.StoreAddress || row?.salonAddress || "",
          productionLocation: row?.productionLocation || row?.region || "",
          dispatchAddress: row?.dispatchAddress || "",
          remarks: row?.remarks || "",
          preparedBy: username,
          items: [
            {
              sno: 1,
              details: buildItemDetails(row),
              hsnCode: pricing.hsnCode,
              unitPrice: pricing.unitPrice,
              totalSqFt: pricing.totalSqFt,
              width: row?.width || "",
              height: row?.height || row?.length || "",
              size: `${row?.width || ""} X ${row?.height || row?.length || ""}`,
              quantity: String(row?.qty || 0),
              lineJobValue: pricing.lineJobValue,
            },
          ],
        })
      );

      window.open("/deliverychallan/", "_blank");
    },
    [customers, username]
  );

  const columnDefs = useMemo(
    () => [
      {
        checkboxSelection: true,
        headerCheckboxSelection: true,
        field: "jobNo",
        headerName: "Job ID",
        filter: true,
      },
      { field: "date", headerName: "Production Date", filter: true },
      { field: "client", headerName: "Client Name", filter: true },
      {
        field: "userName",
        headerName: "Account Manager",
        filter: true,
        minWidth: 180,
        valueGetter: (params) =>
          params.data?.userName ||
          params.data?.username ||
          params.data?.accountManager ||
          params.data?.accountmanager ||
          "",
      },
      {
        field: "region",
        headerName: "Region",
        filter: true,
        minWidth: 140,
        valueGetter: (params) => params.data?.region || params.data?.productionLocation || "",
      },
      {
        field: "productionLocation",
        headerName: "Production Location",
        filter: true,
        minWidth: 190,
        valueGetter: (params) => params.data?.productionLocation || params.data?.region || "",
      },
      { field: "salonAddress", headerName: "SalonAddress" },
      {
        headerName: "Delivery Timestamp",
        colId: "deliveryTimestamp",
        minWidth: 240,
        cellRenderer: DeliveryTimestampCell,
        sortable: false,
        filter: false,
        suppressMenu: true,
      },
      {
        headerName: "Delivery Challan",
        minWidth: 180,
        filter: false,
        sortable: false,
        cellRenderer: (params) => {
          const meta = getDeliveryChallanMeta(params.data);

          if (!meta.isCreated) return "-";

          return (
            <button
              type="button"
              className="btn btn-sm btn-primary"
              onClick={() => openDeliveryChallanFromRow(params.data)}
            >
              {meta.no || "View Challan"}
            </button>
          );
        },
      },
    ],
    [openDeliveryChallanFromRow]
  );

  const defaultColDef = useMemo(
    () => ({
      sortable: true,
      resizable: true,
      filter: "agTextColumnFilter",
      flex: 1,
    }),
    []
  );

  const handleExportExcel = () => gridRef.current.api.exportDataAsExcel();
  const handleExportCSV = () => gridRef.current.api.exportDataAsCsv();

  return (
    <div className="page-wrapper">
      <div className="content container-fluid">
        <style>{`
          .delivery-challan-modal-root{z-index:2000 !important;}
          .delivery-challan-backdrop{z-index:1990 !important;}
          .delivery-challan-modal-root .modal-dialog{
            max-width:min(1100px,72vw);
            margin:1.75rem 2rem 1.75rem auto;
          }
          .delivery-challan-modal-root .form-control[readonly]{
            white-space:normal;
            overflow-wrap:anywhere;
          }
        `}</style>
        <ToastContainer
          position="top-center"
          className="p-3"
          style={{ zIndex: 99999, marginTop: "20px" }}
        >
          <Toast
            show={showTopToast}
            onClose={() => setShowTopToast(false)}
            delay={2500}
            autohide
            bg={topToastVariant}
          >
            <Toast.Header closeButton>
              <strong className="me-auto">
                {topToastVariant === "warning"
                  ? "Warning"
                  : topToastVariant === "success"
                  ? "Success"
                  : "Error"}
              </strong>
            </Toast.Header>
            <Toast.Body className={topToastVariant === "warning" ? "text-dark" : "text-white"}>
              {topToastMessage}
            </Toast.Body>
          </Toast>
        </ToastContainer>

        <div className="page-header">
          <Row>
            <Col>
              <Link to={all_routes.dashboard}>Dashboard</Link>
            </Col>
          </Row>
        </div>

        <Form className="mb-3">
          <Row className="align-items-end">
            <Col md={3}>
              <Form.Label>Delivery Person</Form.Label>
              <Form.Select value={deliverPersonNameSelect} onChange={handleDeliverNameChange}>
                <option value="">Select</option>
                {filteredUserNames.map((user, idx) => (
                  <option key={idx} value={user}>
                    {user}
                  </option>
                ))}
              </Form.Select>
            </Col>

            <Col md={2}>
              <Form.Label>Delivery Started</Form.Label>
              <Form.Control
                type="datetime-local"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
              />
            </Col>

            <Col md={2}>
              <Form.Label>Delivery Completed</Form.Label>
              <Form.Control
                type="datetime-local"
                value={deliveryOutDate}
                onChange={(e) => setDeliveryOutDate(e.target.value)}
              />
            </Col>

            <Col md={2}>
              <Form.Label>Delivery Mode</Form.Label>
              <Form.Select
                value={handTempoDelivery}
                onChange={(e) => setHandTempoDelivery(e.target.value)}
              >
                <option value="">Select</option>
                <option value="Comart to Deliver">Comart to Deliver</option>
                <option value="Customer Pick-Up from Comart">Customer Pick-Up</option>
                <option value="Comart Courier">Comart Courier</option>
              </Form.Select>
            </Col>

            <Col md={3} className="d-flex gap-2 flex-wrap">
              <Button onClick={handleAddDeliveryJob}>Add</Button>
            
              <Button variant="outline-secondary" onClick={() => fetchDeliveryByLocation({ forceRefresh: true })} disabled={loading}>
                <FaSyncAlt />
              </Button>
              <Button onClick={handleExportExcel}>Excel</Button>
              <Button onClick={handleExportCSV}>CSV</Button>
            </Col>
          </Row>
        </Form>

      

      <Row className="mb-3 align-items-end">
  <Col md={12} className="d-flex gap-2 flex-wrap">
    <Button variant="secondary" onClick={handleSelectFilteredRows}>
      Select Filtered Rows
    </Button>

    <Button variant="outline-secondary" onClick={handleClearSelection}>
      Clear Selection
    </Button>

    <Button variant="primary" onClick={handleOpenDeliveryChallanModal}>
      Create Challan
    </Button>

    <Button variant="success" onClick={handleOpenInvoicePreview}>
      Invoice Preview
    </Button>
  </Col>
</Row>

        {loading && <Spinner animation="border" />}
        {error && <Alert variant="danger">{error}</Alert>}

        <div className="ag-theme-alpine" style={{ height: 600 }}>
          <AgGridReact
            ref={gridRef}
            rowData={filteredData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            onSelectionChanged={handleSelectionChanged}
            pagination={true}
            paginationPageSize={25}
            rowSelection="multiple"
            suppressRowClickSelection={true}
            context={{
              rowTimestamps,
              setRowTimestamps,
              // saveTimestamp,
            }}
            getRowId={(params) => params.data.__rowKey}
            animateRows={false}
            rowBuffer={8}
            suppressCellFocus={true}
          />
        </div>

        {showNotification && (
          <Notification
            headline="Deadline Alert!"
            message={notificationMessage ? [notificationMessage] : []}
            onClose={() => setShowNotification(false)}
            show={showNotification}
            containerBg="rgba(116, 143, 231, 0.445)"
            bgColor="blue"
            headerColor="#5b79ff"
          />
        )}

        <Modal
          show={showChallanModal}
          onHide={() => setShowChallanModal(false)}
          centered
          size="xl"
          fullscreen="lg-down"
          className="delivery-challan-modal-root"
          backdropClassName="delivery-challan-backdrop"
        >
          <Modal.Header closeButton>
            <Modal.Title>Edit Delivery Challan</Modal.Title>
          </Modal.Header>
          <Modal.Body style={{ maxHeight: "80vh", overflowY: "auto" }}>
            <Row className="g-3">
              <Col md={6}>
                <Form.Group>
                  <Form.Label>Address</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={5}
                    value={challanForm.customerAddress}
                    onChange={(e) =>
                      setChallanForm((prev) => ({
                        ...prev,
                        customerAddress: e.target.value,
                      }))
                    }
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group>
                  <Form.Label>Store Address</Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={4}
                    value={challanForm.storeAddress}
                    onChange={(e) =>
                      setChallanForm((prev) => ({
                        ...prev,
                        storeAddress: e.target.value,
                      }))
                    }
                  />
                </Form.Group>
              </Col>
              <Col md={3}>
                <Form.Group>
                  <Form.Label>GST No</Form.Label>
                  <Form.Control
                    value={challanForm.customerGstNo}
                    onChange={(e) =>
                      setChallanForm((prev) => ({
                        ...prev,
                        customerGstNo: e.target.value,
                      }))
                    }
                  />
                </Form.Group>
              </Col>
              <Col md={3}>
                <Form.Group>
                <Form.Label>Job Value</Form.Label>
                <Form.Control
                  value={challanForm.jobValue}
                  placeholder="Enter Job Value"
                  onChange={(e) =>
                    setChallanForm((prev) => ({
                      ...prev,
                      jobValue: e.target.value,
                    }))
                  }
                />
              </Form.Group>
            </Col>
              <Col md={6}>
                <Form.Group>
                  <Form.Label>Contact Person</Form.Label>
                  <Form.Control
                    value={challanForm.cpName}
                    onChange={(e) =>
                      setChallanForm((prev) => ({
                        ...prev,
                        cpName: e.target.value,
                      }))
                    }
                  />
                </Form.Group>
              </Col>
            </Row>

            <div className="mt-4">
              <h6 className="mb-3">Selected Items</h6>
              {challanForm.items.map((item, index) => (
                <Row key={`${item.rowId}-${index}`} className="g-3 mb-2 align-items-end">
                  <Col md={2}>
                    <Form.Group>
                      <Form.Label>Job No</Form.Label>
                      <Form.Control value={item.jobNo} readOnly />
                    </Form.Group>
                  </Col>
                  <Col md={8}>
                    <Form.Group>
                      <Form.Label>Details</Form.Label>
                      <Form.Control as="textarea" rows={4} value={item.details} readOnly />
                    </Form.Group>
                  </Col>
                  <Col md={2}>
                    <Form.Group>
                      <Form.Label>HSN</Form.Label>
                      <Form.Control
                        value={item.hsnCode}
                        placeholder="Enter HSN"
                        onChange={(e) =>
                          setChallanForm((prev) => ({
                            ...prev,
                            items: prev.items.map((currentItem, currentIndex) =>
                              currentIndex === index
                                ? { ...currentItem, hsnCode: e.target.value }
                                : currentItem
                            ),
                          }))
                        }
                      />
                    </Form.Group>
                  </Col>
                  <Col md={2}>
                    <Form.Group>
                      <Form.Label>Rate / Sq Ft</Form.Label>
                      <Form.Control value={formatAmount(item.unitPrice)} readOnly />
                    </Form.Group>
                  </Col>
                  <Col md={2}>
                    <Form.Group>
                      <Form.Label>Sq Ft</Form.Label>
                      <Form.Control value={formatAmount(item.totalSqFt)} readOnly />
                    </Form.Group>
                  </Col>
                  <Col md={2}>
                    <Form.Group>
                      <Form.Label>Line Value</Form.Label>
                      <Form.Control value={formatAmount(item.lineJobValue)} readOnly />
                    </Form.Group>
                  </Col>
                </Row>
              ))}
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowChallanModal(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCreateDeliveryChallan}>
              Create Challan
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </div>
  );
};

export default Delivery;
